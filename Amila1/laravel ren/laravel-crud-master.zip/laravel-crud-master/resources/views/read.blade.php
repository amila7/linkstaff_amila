@include('inc.header')
  
      
      <h2>{{ $article->title }}</h2>
      <h4>{{ $article->description }}</h4>

    

@include('inc.footer')